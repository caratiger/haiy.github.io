/**
  * Created by dz-h on 16-7-28.
  */
object HelloWorld{
  def main(args: Array[String]){
    println("Hello world!");
  }
}