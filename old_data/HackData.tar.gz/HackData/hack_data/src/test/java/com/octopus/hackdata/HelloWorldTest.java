package com.octopus.hackdata;

import org.junit.Test;

/**
 * Created by dz-h on 16-7-28.
 */
public class HelloWorldTest {
    @Test
    public void HelloWorldTest(){
        System.out.println("HelloWorld");
    }
}
