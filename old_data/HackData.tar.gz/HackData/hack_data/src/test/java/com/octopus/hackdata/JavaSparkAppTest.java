package com.octopus.hackdata;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static com.sun.xml.internal.ws.dump.LoggingDumpTube.Position.Before;
import static junit.framework.Assert.assertEquals;

/**
 * Created by dz-h on 16-7-27.
 */
public class JavaSparkAppTest {
    private JavaSparkContext sparkCtx;

    @Test
    public void init() throws IllegalArgumentException, IOException {
        //ctxtBuilder = new ContextBuilder(tempFolder);
        SparkConf conf = new SparkConf();
        conf.setMaster("local[2]");
        conf.setAppName("junit");
        sparkCtx = new JavaSparkContext(conf);
    }
    @Test
    public void test() {
        final List<Integer> nums = new ArrayList<Integer>();
        nums.add(3);
        nums.add(4);
        nums.add(2);
        try {
            init();
        } catch (IOException e) {
            e.printStackTrace();
        }
        JavaRDD<Integer> rdd = sparkCtx.parallelize(nums,1);
        System.out.println(rdd.count());
        assertEquals(3, rdd.count());
    }
}
