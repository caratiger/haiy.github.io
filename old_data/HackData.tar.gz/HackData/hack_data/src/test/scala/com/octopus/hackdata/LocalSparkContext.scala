package com.octopus.hackdata

import org.apache.spark.{SparkConf, SparkContext}
import org.scalatest.Matchers._

/**
  * Provides a method to run tests against a {@link SparkContext} variable that is correctly stopped
  * after each test.
  */

trait LocalSparkContext {
  /** Runs `f` on a new SparkContext and ensures that it is stopped afterwards. */

  @transient var sc: SparkContext = _

  def withSpark[T](f: SparkContext => T) = {
    val conf = new SparkConf()
    sc = new SparkContext("local", "test", conf)
    try {
      f(sc)
    } finally {
      sc.stop()
    }
  }
}