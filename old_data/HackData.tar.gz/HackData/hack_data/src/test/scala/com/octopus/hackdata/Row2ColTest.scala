package com.octopus.hackdata

import org.scalatest.FunSuite

/**
  * Created by dz-h on 16-7-28.
  */
class Row2ColTest extends FunSuite with LocalSparkContext{
  test("convert row to columns")
  withSpark{ sc =>
    df = sqlContext.createDataFrame([
      ("a", 1, "m1"), ("a", 1, "m2"), ("a", 2, "m3"),
    ("a", 3, "m4"), ("b", 4, "m1"), ("b", 1, "m2"),
    ("b", 2, "m3"), ("c", 3, "m1"), ("c", 4, "m3"),
    ("c", 5, "m4"), ("d", 6, "m1"), ("d", 1, "m2"),
    ("d", 2, "m3"), ("d", 3, "m4"), ("d", 4, "m5"),
    ("e", 4, "m1"), ("e", 5, "m2"), ("e", 1, "m3"),
    ("e", 1, "m4"), ("e", 1, "m5")],
    ("a", "cnt", "major"))

  }

}
