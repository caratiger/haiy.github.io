package com.octopus.hackdata

import org.apache.spark.{SparkConf, SparkContext, SparkEnv, SparkException}
import org.scalatest.FunSuite

/**
  * Created by dz-h on 16-7-28.
  */
class SimpleSparkTest extends FunSuite with LocalSparkContext{
  test("Only one SparkContext may be active at a time") {
    // Regression test for SPARK-4180
    val conf = new SparkConf().setAppName("test").setMaster("local")
      .set("spark.driver.allowMultipleContexts", "false")
    sc = new SparkContext(conf)
    val envBefore = SparkEnv.get
    // A SparkContext is already running, so we shouldn't be able to create a second one
    intercept[SparkException] { new SparkContext(conf) }
    val envAfter = SparkEnv.get
    // SparkEnv and other context variables should be the same
  }

  test("simple word count") {
    withSpark{ sc =>
      val res = sc.parallelize("hal o  sa asas d a s d")
        .map{case a => a -> 1}.reduceByKey{(a,b) => a+b}.collect()
      println(res.toList)
    }
  }


}
